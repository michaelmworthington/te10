js.jquery
*********

Introduction
============

This library packages `jQuery`_ for `fanstatic`_. It is aware of jQuery's
structure and different modes (normal, minified).

.. _`fanstatic`: http://fanstatic.org
.. _`jQuery`: http://jquery.com/

This requires integration between your web framework and ``fanstatic``,
and making sure that the original resources (shipped in the ``resources``
directory in ``js.jquery``) are published to some URL.
