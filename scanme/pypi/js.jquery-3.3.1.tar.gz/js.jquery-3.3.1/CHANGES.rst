CHANGES
*******

3.3.1 (2018-03-20)
==================

- Update to jQuery 3.3.1, released 2018-01-20 (`release notes 3.3.1`_).

.. _`release notes 3.3.1`: https://blog.jquery.com/2018/01/20/jquery-3-3-1-fixed-dependencies-in-release-tag/


3.2.1 (2018-02-01)
==================

- Update to jQuery 3.2.1, released 2017-03-20 (`release notes 3.2.1`_).

.. _`release notes 3.2.1`: https://blog.jquery.com/2017/03/20/jquery-3-2-1-now-available/


1.9.1 (2013-03-03)
==================

- Update to jQuery 1.9.1, released 2013-02-04 (`release notes 1.9.1`_).

.. _`release notes 1.9.1`: http://blog.jquery.com/2013/02/04/jquery-1-9-1-released/

1.8.2 (2012-09-21)
==================

- Update to jQuery 1.8.2, released 2012-09-20 (`release notes 1.8.2`_).

.. _`release notes 1.8.2`: http://blog.jquery.com/2012/09/20/jquery-1-8-2-released/


1.8.1 (2012-09-18)
==================

- Update to jQuery 1.8.1, released 2012-08-30 (`release notes 1.8.1`_).

.. _`release notes 1.8.1`: http://blog.jquery.com/2012/08/30/jquery-1-8-1-released/


1.8.0 (2012-08-22)
==================

- Update to jQuery 1.8, released 2012-08-09 (`release notes 1.8`_).

.. _`release notes 1.8`: http://blog.jquery.com/2012/08/09/jquery-1-8-released/


1.7.2 (2012-08-22)
==================

- Update to jQuery 1.7.2, released 2012-03-21 (`release notes 1.7.2`_)

.. _`release notes 1.7.2`: http://blog.jquery.com/2012/03/21/jquery-1-7-2-released/


1.7.1 (2011-12-01)
==================

- Update to v 1.7.1


1.6.1 (2011-05-24)
==================

- Update to v 1.6.1


1.6 (2011-05-07)
================

- Update to v 1.6


1.4.4 (2011-01-06)
==================

- Rewrote `hurry.jquery`_ to use `fanstatic`_ instead of `hurry.resource`_.

.. _`hurry.jquery`: http://pypi.python.org/pypi/hurry.jquery
.. _`hurry.resource`: http://pypi.python.org/pypi/hurry.resource
.. _`fanstatic`: http://fanstatic.org
