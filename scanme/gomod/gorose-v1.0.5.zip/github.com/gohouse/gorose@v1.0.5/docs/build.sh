#!/usr/bin/env bash

# EasyDoc https://easydoc.089858.com

# 依赖：EasyDoc二进制文件要放在全局环境目录里，并确定有可执行权限。
# chmod +x build.sh
# ./build.sh
easydoc -build

