package sqlite3

import _ "github.com/mattn/go-sqlite3"
