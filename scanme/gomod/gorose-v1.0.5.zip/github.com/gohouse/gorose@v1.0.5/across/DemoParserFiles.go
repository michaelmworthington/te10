package across

// 临时配置, 方便 test 测试
var DemoParserFiles = map[string]string{
	"json": "/Users/fizz/go/src/github.com/gohouse/gorose/examples/demoParserFiles/mysql_cluster.json",
	//"json": "/Users/fizz/go/src/github.com/gohouse/gorose/examples/demoParserFiles/mysql.json",
	"toml": "/Users/fizz/go/src/github.com/gohouse/gorose/examples/demoParserFiles/mysql.toml",
	"ini":  "/Users/fizz/go/src/github.com/gohouse/gorose/examples/demoParserFiles/mysql.ini",
}
